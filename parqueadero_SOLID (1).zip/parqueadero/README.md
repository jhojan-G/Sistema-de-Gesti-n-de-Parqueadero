# Sistema de Parqueadero

Sistema orientado a objetos para la administración de un parqueadero con registro de vehículos, control de acceso, tarifas diferenciadas y abonos mensuales.

---

## Estructura del Proyecto

```
parqueadero/
└── src/main/java/parqueadero/
    ├── modelo/
    │   ├── Vehiculo.java        ← Clase abstracta base
    │   ├── Carro.java
    │   ├── Moto.java
    │   ├── Bicicleta.java
    │   ├── EspacioParqueo.java
    │   ├── Ticket.java
    │   ├── Tarifa.java
    │   └── Abono.java
    ├── interfaces/
    │   ├── Tarifable.java       ← ISP
    │   ├── Abonado.java         ← ISP
    │   └── Registrable.java     ← ISP
    ├── estrategia/
    │   ├── EstrategiaTarifa.java ← DIP / OCP
    │   └── TarifaPorHora.java
    ├── servicio/
    │   ├── CalculadorTarifa.java
    │   ├── GestorAbonos.java
    │   ├── GestorEspacios.java
    │   └── ControlAcceso.java
    └── main/
        └── Main.java
```

---

## Cómo compilar y ejecutar

```bash
# Desde la raíz del proyecto
find src -name "*.java" > sources.txt
javac -d out @sources.txt
java -cp out parqueadero.main.Main
```

---

## Entidades principales

| Clase | Rol |
|---|---|
| `Vehiculo` | Clase abstracta: placa, propietario, tipo |
| `Carro / Moto / Bicicleta` | Subtipos concretos |
| `EspacioParqueo` | Espacio físico con zona y tipo permitido |
| `Ticket` | Registro de ingreso/salida con hora y costo |
| `Tarifa` | Precio por hora y mínimo por tipo de vehículo |
| `Abono` | Suscripción mensual con fecha de vigencia |

---

## Aplicación de Principios SOLID

### S — Single Responsibility Principle (Responsabilidad Única)

Cada clase tiene una sola razón para cambiar:

- **`Vehiculo` y subclases** → solo representan datos del vehículo.
- **`EspacioParqueo`** → solo gestiona el estado de ocupación de un espacio físico.
- **`Ticket`** → solo almacena los datos de un turno de parqueo.
- **`Tarifa`** → solo almacena la configuración de precios (sin calcular).
- **`Abono`** → solo administra datos del abono mensual (vigencia, costo).
- **`ControlAcceso`** → únicamente controla el ingreso y salida de vehículos.
- **`GestorAbonos`** → únicamente registra y consulta abonos.
- **`GestorEspacios`** → únicamente administra el estado de los espacios.
- **`CalculadorTarifa`** → únicamente delega el cálculo de tarifas a la estrategia.

### O — Open/Closed Principle (Abierto/Cerrado)

El sistema está abierto para extensión y cerrado para modificación:

- **`EstrategiaTarifa`** es una interfaz; agregar una nueva estrategia de cobro (por ejemplo, tarifa nocturna o tarifa plana) no requiere tocar `CalculadorTarifa` ni `ControlAcceso`.
- **`GestorEspacios.buscarEspacioDisponible()`** filtra por `getTipo()`. Agregar un nuevo tipo de vehículo (por ejemplo, `Camion`) solo requiere crear la subclase y registrar espacios del tipo `"Camion"`, sin modificar ningún servicio existente.
- El mapa de `Tarifa` en `Main` permite registrar el precio del nuevo tipo en un solo lugar.

### L — Liskov Substitution Principle (Sustitución de Liskov)

`Carro`, `Moto` y `Bicicleta` son completamente intercambiables por `Vehiculo`:

- `ControlAcceso.registrarIngreso(Vehiculo vehiculo)` recibe cualquier subtipo sin distinción y funciona correctamente en todos los casos.
- `GestorEspacios.buscarEspacioDisponible(Vehiculo vehiculo)` consulta `getTipo()` de forma polimórfica; ningún subtipo rompe el contrato de la clase base.
- Demostrado en `Main` donde los tres tipos se pasan directamente a los mismos métodos.

### I — Interface Segregation Principle (Segregación de Interfaces)

Las interfaces son específicas y cohesivas; ningún cliente implementa métodos que no usa:

- **`Tarifable`** → solo `calcularCosto()`. Implementado por `CalculadorTarifa`.
- **`Abonado`** → solo `registrarAbono()`, `obtenerAbonoVigente()`, `tieneAbonoVigente()`. Implementado por `GestorAbonos`.
- **`Registrable`** → solo `registrarIngreso()` y `registrarSalida()`. Implementado por `ControlAcceso`.

Ninguna clase está obligada a implementar métodos de otra responsabilidad.

### D — Dependency Inversion Principle (Inversión de Dependencias)

Los módulos de alto nivel no dependen de concreciones:

- **`ControlAcceso`** recibe `Tarifable` (abstracción), no `CalculadorTarifa` directamente.
- **`CalculadorTarifa`** recibe `EstrategiaTarifa` (abstracción), no `TarifaPorHora` directamente.
- Toda la construcción del grafo de dependencias ocurre en `Main` (composición en el punto de entrada), permitiendo sustituir cualquier implementación sin tocar las clases de negocio.

---

## Polimorfismo y composición

- **Polimorfismo**: `Carro`, `Moto` y `Bicicleta` sobreescriben `getTipo()`. Los servicios trabajan con `Vehiculo` y el comportamiento varía automáticamente según el tipo real.
- **Composición**: `ControlAcceso` está compuesto de `GestorEspacios`, `GestorAbonos` y `Tarifable`; no los hereda. Esto favorece bajo acoplamiento y alta cohesión.

---

## Conclusiones y lecciones aprendidas

1. **SOLID hace el código extensible de verdad.** Al agregar `Bicicleta` al sistema, no se modificó ningún servicio existente; solo se añadió la clase y sus espacios y tarifas.

2. **La inyección de dependencias (DIP) facilita las pruebas.** Cualquier estrategia de tarifa puede reemplazarse en `Main` por un mock o una implementación alternativa sin tocar `ControlAcceso`.

3. **Las interfaces pequeñas (ISP) evitan el acoplamiento innecesario.** Si en el futuro se necesita un servicio que solo verifique abonos, puede recibir `Abonado` sin arrastrar lógica de acceso.

4. **SRP reduce los conflictos de cambio.** Los cambios en la lógica de tarifas solo afectan `EstrategiaTarifa` y sus implementaciones; no tienen impacto en el modelo ni en el control de acceso.

5. **LSP garantiza comportamiento uniforme.** Tratar todos los vehículos como `Vehiculo` permite que el sistema sea consistente hoy y escalable hacia nuevos tipos en el futuro.
