package parqueadero.modelo;

/**
 * Bicicleta — tipo de vehículo concreto.
 * SOLID: LSP — sustituible por Vehiculo sin cambiar el comportamiento del sistema.
 */
public class Bicicleta extends Vehiculo {

    public Bicicleta(String placa, String propietario) {
        super(placa, propietario);
    }

    @Override
    public String getTipo() { return "Bicicleta"; }
}
