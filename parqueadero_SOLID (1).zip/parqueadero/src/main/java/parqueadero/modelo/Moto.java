package parqueadero.modelo;

/**
 * Moto — tipo de vehículo concreto.
 * SOLID: LSP — sustituible por Vehiculo sin cambiar el comportamiento del sistema.
 */
public class Moto extends Vehiculo {

    public Moto(String placa, String propietario) {
        super(placa, propietario);
    }

    @Override
    public String getTipo() { return "Moto"; }
}
