package parqueadero.modelo;

import java.time.LocalDate;

/**
 * Abono — representa una suscripción mensual de un vehículo al parqueadero.
 * SOLID: SRP — solo administra datos del abono mensual.
 */
public class Abono {

    private final String placa;
    private final String propietario;
    private final LocalDate fechaInicio;
    private final LocalDate fechaFin;
    private final double costo;

    public Abono(String placa, String propietario, LocalDate fechaInicio, int meses, double costo) {
        this.placa = placa.toUpperCase();
        this.propietario = propietario;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaInicio.plusMonths(meses).minusDays(1);
        this.costo = costo;
    }

    public String getPlaca() { return placa; }
    public String getPropietario() { return propietario; }
    public LocalDate getFechaFin() { return fechaFin; }
    public double getCosto() { return costo; }

    /** Verifica si el abono está vigente en la fecha dada. */
    public boolean esVigente(LocalDate fecha) {
        return !fecha.isBefore(fechaInicio) && !fecha.isAfter(fechaFin);
    }

    @Override
    public String toString() {
        return String.format("Abono [%s / %s] Válido: %s → %s | $%.0f",
                placa, propietario, fechaInicio, fechaFin, costo);
    }
}
