package parqueadero.modelo;

/**
 * Tarifa — almacena la configuración de precios por tipo de vehículo.
 * SOLID: SRP — solo representa datos de tarifa, sin lógica de cálculo.
 */
public class Tarifa {

    private final String tipoVehiculo;
    private final double precioPorHora;
    private final double precioMinimo; // cobro mínimo (primera fracción)

    public Tarifa(String tipoVehiculo, double precioPorHora, double precioMinimo) {
        this.tipoVehiculo = tipoVehiculo;
        this.precioPorHora = precioPorHora;
        this.precioMinimo = precioMinimo;
    }

    public String getTipoVehiculo() { return tipoVehiculo; }
    public double getPrecioPorHora() { return precioPorHora; }
    public double getPrecioMinimo() { return precioMinimo; }

    @Override
    public String toString() {
        return String.format("Tarifa [%s] — $%.0f/hora | Mínimo: $%.0f",
                tipoVehiculo, precioPorHora, precioMinimo);
    }
}
