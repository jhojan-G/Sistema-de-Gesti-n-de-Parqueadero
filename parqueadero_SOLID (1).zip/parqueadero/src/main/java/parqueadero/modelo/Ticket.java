package parqueadero.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Ticket — representa el registro de ingreso/salida de un vehículo.
 * SOLID: SRP — solo almacena datos del turno de parqueo.
 */
public class Ticket {

    private static int contador = 1;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final int id;
    private final Vehiculo vehiculo;
    private final EspacioParqueo espacio;
    private final LocalDateTime horaIngreso;
    private LocalDateTime horaSalida;
    private double totalCobrado;
    private boolean cerrado;

    public Ticket(Vehiculo vehiculo, EspacioParqueo espacio) {
        this.id = contador++;
        this.vehiculo = vehiculo;
        this.espacio = espacio;
        this.horaIngreso = LocalDateTime.now();
        this.cerrado = false;
        this.totalCobrado = 0;
    }

    /** Cierra el ticket al momento de la salida. */
    public void cerrar(double totalCobrado) {
        if (cerrado) throw new IllegalStateException("El ticket #" + id + " ya está cerrado.");
        this.horaSalida = LocalDateTime.now();
        this.totalCobrado = totalCobrado;
        this.cerrado = true;
    }

    public int getId() { return id; }
    public Vehiculo getVehiculo() { return vehiculo; }
    public EspacioParqueo getEspacio() { return espacio; }
    public LocalDateTime getHoraIngreso() { return horaIngreso; }
    public LocalDateTime getHoraSalida() { return horaSalida; }
    public double getTotalCobrado() { return totalCobrado; }
    public boolean isCerrado() { return cerrado; }

    @Override
    public String toString() {
        String salida = cerrado ? horaSalida.format(FMT) : "En curso";
        return String.format(
            "Ticket #%d | %s | Espacio: %s | Ingreso: %s | Salida: %s | Total: $%.0f",
            id, vehiculo, espacio.getCodigo(), horaIngreso.format(FMT), salida, totalCobrado
        );
    }
}
