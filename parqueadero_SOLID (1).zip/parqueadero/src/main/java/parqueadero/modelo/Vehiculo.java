package parqueadero.modelo;

/**
 * Clase abstracta Vehiculo — base para todos los tipos de vehículo.
 * SOLID: SRP — solo representa datos del vehículo.
 *        LSP — Carro, Moto y Bicicleta son sustituibles por Vehiculo.
 */
public abstract class Vehiculo {

    private final String placa;
    private final String propietario;

    public Vehiculo(String placa, String propietario) {
        if (placa == null || placa.isBlank())
            throw new IllegalArgumentException("La placa no puede estar vacía.");
        this.placa = placa.toUpperCase();
        this.propietario = propietario;
    }

    public String getPlaca() { return placa; }
    public String getPropietario() { return propietario; }

    /** Retorna el tipo de vehículo como texto (para tarifas, reportes, etc.) */
    public abstract String getTipo();

    @Override
    public String toString() {
        return getTipo() + " [" + placa + "] — " + propietario;
    }
}
