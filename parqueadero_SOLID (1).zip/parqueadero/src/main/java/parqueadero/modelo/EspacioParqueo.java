package parqueadero.modelo;

/**
 * EspacioParqueo — representa un espacio físico en el parqueadero.
 * SOLID: SRP — solo gestiona el estado de ocupación de un espacio.
 */
public class EspacioParqueo {

    private final String codigo;
    private final String zona;
    private final String tipoPermitido; // "Carro", "Moto", "Bicicleta"
    private boolean ocupado;

    public EspacioParqueo(String codigo, String zona, String tipoPermitido) {
        this.codigo = codigo;
        this.zona = zona;
        this.tipoPermitido = tipoPermitido;
        this.ocupado = false;
    }

    public String getCodigo() { return codigo; }
    public String getZona() { return zona; }
    public String getTipoPermitido() { return tipoPermitido; }
    public boolean isOcupado() { return ocupado; }

    public void ocupar() {
        if (ocupado) throw new IllegalStateException("El espacio " + codigo + " ya está ocupado.");
        this.ocupado = true;
    }

    public void liberar() {
        if (!ocupado) throw new IllegalStateException("El espacio " + codigo + " ya está libre.");
        this.ocupado = false;
    }

    @Override
    public String toString() {
        return "Espacio " + codigo + " [Zona: " + zona + ", Tipo: " + tipoPermitido
                + ", Estado: " + (ocupado ? "OCUPADO" : "LIBRE") + "]";
    }
}
