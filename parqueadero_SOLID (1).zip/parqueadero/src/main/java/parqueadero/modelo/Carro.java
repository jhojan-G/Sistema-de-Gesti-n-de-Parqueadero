package parqueadero.modelo;

/**
 * Carro — tipo de vehículo concreto.
 * SOLID: LSP — sustituible por Vehiculo sin cambiar el comportamiento del sistema.
 */
public class Carro extends Vehiculo {

    public Carro(String placa, String propietario) {
        super(placa, propietario);
    }

    @Override
    public String getTipo() { return "Carro"; }
}
