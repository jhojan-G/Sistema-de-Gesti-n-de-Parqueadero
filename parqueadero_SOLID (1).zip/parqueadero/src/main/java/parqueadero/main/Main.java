package parqueadero.main;

import parqueadero.estrategia.TarifaPorHora;
import parqueadero.modelo.*;
import parqueadero.servicio.*;

import java.time.LocalDate;
import java.util.Map;

/**
 * Main — clase demostrativa del sistema de parqueadero.
 * Muestra todos los flujos: ingreso, salida, abonos y consulta de espacios.
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║     SISTEMA DE PARQUEADERO - v1.0        ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // ─── 1. Configurar tarifas (OCP: agregar nuevo tipo = agregar entrada al mapa)
        Map<String, Tarifa> tarifas = Map.of(
            "Carro",     new Tarifa("Carro",     3000, 3000),   // $3.000/hora, mínimo $3.000
            "Moto",      new Tarifa("Moto",      2000, 2000),   // $2.000/hora, mínimo $2.000
            "Bicicleta", new Tarifa("Bicicleta",  500,  500)    // $500/hora,   mínimo $500
        );

        // ─── 2. Construir servicios con inyección de dependencias (DIP)
        GestorEspacios gestorEspacios = new GestorEspacios();
        GestorAbonos   gestorAbonos   = new GestorAbonos();
        CalculadorTarifa calculador   = new CalculadorTarifa(new TarifaPorHora(tarifas));
        ControlAcceso controlAcceso   = new ControlAcceso(gestorEspacios, gestorAbonos, calculador);

        // ─── 3. Registrar espacios por zona
        gestorEspacios.agregarEspacio(new EspacioParqueo("A1", "Norte", "Carro"));
        gestorEspacios.agregarEspacio(new EspacioParqueo("A2", "Norte", "Carro"));
        gestorEspacios.agregarEspacio(new EspacioParqueo("B1", "Sur",   "Moto"));
        gestorEspacios.agregarEspacio(new EspacioParqueo("B2", "Sur",   "Moto"));
        gestorEspacios.agregarEspacio(new EspacioParqueo("C1", "Bici",  "Bicicleta"));
        gestorEspacios.agregarEspacio(new EspacioParqueo("C2", "Bici",  "Bicicleta"));

        gestorEspacios.imprimirEstado();

        // ─── 4. Registrar un abono mensual (ISP: GestorAbonos implementa Abonado)
        System.out.println("\n── Registrando abono mensual ──");
        Abono abono = new Abono("MNO789", "Carlos Abonado", LocalDate.now(), 1, 80_000);
        gestorAbonos.registrarAbono(abono);

        // ─── 5. Registrar ingresos (LSP: Carro, Moto y Bicicleta son tratados como Vehiculo)
        System.out.println("\n── Registrando ingresos ──");
        Vehiculo carro1    = new Carro("ABC123", "Ana García");
        Vehiculo moto1     = new Moto("XYZ456", "Luis Pérez");
        Vehiculo bici1     = new Bicicleta("BIC001", "María López");
        Vehiculo carroAbonado = new Carro("MNO789", "Carlos Abonado");

        controlAcceso.registrarIngreso(carro1);
        controlAcceso.registrarIngreso(moto1);
        controlAcceso.registrarIngreso(bici1);
        controlAcceso.registrarIngreso(carroAbonado);

        gestorEspacios.imprimirEstado();

        // ─── 6. Simular salidas
        System.out.println("\n── Registrando salidas ──");
        controlAcceso.registrarSalida("ABC123");
        controlAcceso.registrarSalida("XYZ456");
        controlAcceso.registrarSalida("BIC001");
        controlAcceso.registrarSalida("MNO789"); // abonado: costo $0

        gestorEspacios.imprimirEstado();

        // ─── 7. Reporte de tickets
        System.out.println("\n── Resumen de tickets ──");
        controlAcceso.listarTickets().forEach(t -> System.out.println("  " + t));

        // ─── 8. Consulta de disponibilidad
        System.out.println("\n── Disponibilidad actual ──");
        System.out.println("  Carros disponibles:     " + gestorEspacios.contarDisponibles("Carro"));
        System.out.println("  Motos disponibles:      " + gestorEspacios.contarDisponibles("Moto"));
        System.out.println("  Bicicletas disponibles: " + gestorEspacios.contarDisponibles("Bicicleta"));

        // ─── 9. Demostración de error controlado
        System.out.println("\n── Prueba de ingreso duplicado (debe lanzar error) ──");
        try {
            controlAcceso.registrarIngreso(new Carro("ABC123", "Ana García"));
        } catch (IllegalStateException e) {
            System.out.println("⚠️  Error esperado: " + e.getMessage());
        }

        System.out.println("\n✅ Demo completada exitosamente.");
    }
}
