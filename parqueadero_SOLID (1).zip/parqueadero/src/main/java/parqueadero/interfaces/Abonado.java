package parqueadero.interfaces;

import parqueadero.modelo.Abono;
import java.util.Optional;

/**
 * Abonado — contrato para verificar y gestionar abonos mensuales.
 * SOLID: ISP — interfaz específica para la funcionalidad de abonos.
 */
public interface Abonado {
    /** Registra un abono mensual para una placa. */
    void registrarAbono(Abono abono);

    /** Retorna el abono vigente de una placa, si existe. */
    Optional<Abono> obtenerAbonoVigente(String placa);

    /** Indica si la placa tiene un abono activo hoy. */
    boolean tieneAbonoVigente(String placa);
}
