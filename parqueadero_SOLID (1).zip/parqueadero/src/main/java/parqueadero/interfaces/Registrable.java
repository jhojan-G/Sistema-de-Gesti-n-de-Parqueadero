package parqueadero.interfaces;

import parqueadero.modelo.Ticket;
import parqueadero.modelo.Vehiculo;

/**
 * Registrable — contrato para el control de acceso (ingreso y salida).
 * SOLID: ISP — interfaz específica para el registro de movimientos.
 */
public interface Registrable {
    /** Registra el ingreso de un vehículo y retorna el ticket generado. */
    Ticket registrarIngreso(Vehiculo vehiculo);

    /** Registra la salida de un vehículo y cierra su ticket. */
    Ticket registrarSalida(String placa);
}
