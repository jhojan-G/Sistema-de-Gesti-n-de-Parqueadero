package parqueadero.interfaces;

import parqueadero.modelo.Vehiculo;

/**
 * Tarifable — contrato para calcular el costo de un turno de parqueo.
 * SOLID: ISP — interfaz específica para el cálculo de tarifas.
 *        DIP — las clases de alto nivel dependen de esta abstracción, no de implementaciones concretas.
 */
public interface Tarifable {
    /**
     * Calcula el costo total para un vehículo dado el tiempo estacionado en minutos.
     */
    double calcularCosto(Vehiculo vehiculo, long minutosEstacionado);
}
