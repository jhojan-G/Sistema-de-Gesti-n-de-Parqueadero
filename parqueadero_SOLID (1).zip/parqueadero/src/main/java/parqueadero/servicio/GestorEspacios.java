package parqueadero.servicio;

import parqueadero.modelo.EspacioParqueo;
import parqueadero.modelo.Vehiculo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * GestorEspacios — servicio que administra los espacios del parqueadero.
 * SOLID: SRP — su única responsabilidad es el estado de los espacios físicos.
 */
public class GestorEspacios {

    private final List<EspacioParqueo> espacios = new ArrayList<>();

    public void agregarEspacio(EspacioParqueo espacio) {
        espacios.add(espacio);
    }

    /**
     * Busca y retorna un espacio libre compatible con el tipo de vehículo.
     * SOLID: OCP — si se agrega un nuevo tipo de vehículo, solo se agregan espacios del tipo
     *              correspondiente; este método no necesita modificarse.
     */
    public Optional<EspacioParqueo> buscarEspacioDisponible(Vehiculo vehiculo) {
        return espacios.stream()
                .filter(e -> !e.isOcupado() && e.getTipoPermitido().equalsIgnoreCase(vehiculo.getTipo()))
                .findFirst();
    }

    public List<EspacioParqueo> listarEspacios() {
        return List.copyOf(espacios);
    }

    public long contarDisponibles(String tipo) {
        return espacios.stream()
                .filter(e -> !e.isOcupado() && e.getTipoPermitido().equalsIgnoreCase(tipo))
                .count();
    }

    public void imprimirEstado() {
        System.out.println("\n📋 Estado de espacios:");
        espacios.forEach(e -> System.out.println("  " + e));
    }
}
