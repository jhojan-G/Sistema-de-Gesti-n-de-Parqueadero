package parqueadero.servicio;

import parqueadero.interfaces.Abonado;
import parqueadero.modelo.Abono;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * GestorAbonos — servicio encargado exclusivamente de los abonos mensuales.
 * SOLID: SRP — su única responsabilidad es administrar abonos.
 *        ISP — implementa solo la interfaz Abonado (no mezcla control de acceso).
 */
public class GestorAbonos implements Abonado {

    private final List<Abono> abonos = new ArrayList<>();

    @Override
    public void registrarAbono(Abono abono) {
        abonos.add(abono);
        System.out.println("✅ Abono registrado: " + abono);
    }

    @Override
    public Optional<Abono> obtenerAbonoVigente(String placa) {
        LocalDate hoy = LocalDate.now();
        return abonos.stream()
                .filter(a -> a.getPlaca().equalsIgnoreCase(placa) && a.esVigente(hoy))
                .findFirst();
    }

    @Override
    public boolean tieneAbonoVigente(String placa) {
        return obtenerAbonoVigente(placa).isPresent();
    }

    public List<Abono> listarAbonos() {
        return List.copyOf(abonos);
    }
}
