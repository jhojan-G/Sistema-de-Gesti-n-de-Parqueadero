package parqueadero.servicio;

import parqueadero.interfaces.Registrable;
import parqueadero.interfaces.Tarifable;
import parqueadero.modelo.EspacioParqueo;
import parqueadero.modelo.Ticket;
import parqueadero.modelo.Vehiculo;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * ControlAcceso — gestiona el ingreso y salida de vehículos.
 * SOLID: SRP — su única responsabilidad es el control de acceso.
 *        ISP — implementa solo la interfaz Registrable.
 *        DIP — recibe GestorEspacios, GestorAbonos y Tarifable por constructor
 *              (no instancia concreciones directamente).
 */
public class ControlAcceso implements Registrable {

    private final GestorEspacios gestorEspacios;
    private final GestorAbonos gestorAbonos;
    private final Tarifable calculador;
    private final List<Ticket> tickets = new ArrayList<>();

    public ControlAcceso(GestorEspacios gestorEspacios,
                         GestorAbonos gestorAbonos,
                         Tarifable calculador) {
        this.gestorEspacios = gestorEspacios;
        this.gestorAbonos = gestorAbonos;
        this.calculador = calculador;
    }

    @Override
    public Ticket registrarIngreso(Vehiculo vehiculo) {
        // Verificar si ya tiene ticket abierto
        boolean yaAdentro = tickets.stream()
                .anyMatch(t -> !t.isCerrado()
                        && t.getVehiculo().getPlaca().equalsIgnoreCase(vehiculo.getPlaca()));
        if (yaAdentro) {
            throw new IllegalStateException("El vehículo " + vehiculo.getPlaca() + " ya está en el parqueadero.");
        }

        EspacioParqueo espacio = gestorEspacios.buscarEspacioDisponible(vehiculo)
                .orElseThrow(() -> new IllegalStateException(
                        "No hay espacios disponibles para " + vehiculo.getTipo()));

        espacio.ocupar();
        Ticket ticket = new Ticket(vehiculo, espacio);
        tickets.add(ticket);

        String tipoAbono = gestorAbonos.tieneAbonoVigente(vehiculo.getPlaca()) ? " [ABONADO]" : "";
        System.out.println("🚗 Ingreso registrado" + tipoAbono + ": " + ticket);
        return ticket;
    }

    @Override
    public Ticket registrarSalida(String placa) {
        Ticket ticket = tickets.stream()
                .filter(t -> !t.isCerrado()
                        && t.getVehiculo().getPlaca().equalsIgnoreCase(placa))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No se encontró ticket abierto para la placa: " + placa));

        long minutos = Duration.between(ticket.getHoraIngreso(), java.time.LocalDateTime.now()).toMinutes();

        double costo;
        if (gestorAbonos.tieneAbonoVigente(placa)) {
            costo = 0; // Abonados no pagan por turno
            System.out.println("💳 Vehículo abonado — sin cobro adicional.");
        } else {
            costo = calculador.calcularCosto(ticket.getVehiculo(), Math.max(minutos, 1));
        }

        ticket.cerrar(costo);
        ticket.getEspacio().liberar();

        System.out.println("🚙 Salida registrada: " + ticket);
        return ticket;
    }

    public List<Ticket> listarTickets() {
        return List.copyOf(tickets);
    }

    public Optional<Ticket> buscarTicketAbierto(String placa) {
        return tickets.stream()
                .filter(t -> !t.isCerrado()
                        && t.getVehiculo().getPlaca().equalsIgnoreCase(placa))
                .findFirst();
    }
}
