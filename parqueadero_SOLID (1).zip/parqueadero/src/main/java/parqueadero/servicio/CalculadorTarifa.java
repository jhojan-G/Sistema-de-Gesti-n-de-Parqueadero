package parqueadero.servicio;

import parqueadero.estrategia.EstrategiaTarifa;
import parqueadero.interfaces.Tarifable;
import parqueadero.modelo.Vehiculo;

/**
 * CalculadorTarifa — servicio que calcula el costo usando una estrategia inyectada.
 * SOLID: DIP — recibe EstrategiaTarifa por constructor (inyección de dependencias),
 *              nunca instancia implementaciones concretas directamente.
 *        SRP — su única responsabilidad es delegar el cálculo a la estrategia.
 *        OCP — aceptar nuevas estrategias sin modificar esta clase.
 */
public class CalculadorTarifa implements Tarifable {

    private final EstrategiaTarifa estrategia;

    public CalculadorTarifa(EstrategiaTarifa estrategia) {
        this.estrategia = estrategia;
    }

    @Override
    public double calcularCosto(Vehiculo vehiculo, long minutosEstacionado) {
        return estrategia.calcular(vehiculo, minutosEstacionado);
    }
}
