package parqueadero.estrategia;

import parqueadero.modelo.Tarifa;
import parqueadero.modelo.Vehiculo;
import java.util.Map;

/**
 * TarifaPorHora — estrategia concreta: cobra por hora según el tipo de vehículo.
 * SOLID: OCP — para agregar un nuevo tipo de vehículo solo se agrega su tarifa al mapa,
 *              sin modificar esta clase ni el calculador.
 *        DIP — implementa EstrategiaTarifa (abstracción).
 */
public class TarifaPorHora implements EstrategiaTarifa {

    private final Map<String, Tarifa> tarifas;

    public TarifaPorHora(Map<String, Tarifa> tarifas) {
        this.tarifas = tarifas;
    }

    @Override
    public double calcular(Vehiculo vehiculo, long minutosEstacionado) {
        Tarifa tarifa = tarifas.get(vehiculo.getTipo());
        if (tarifa == null) {
            throw new IllegalArgumentException("No hay tarifa configurada para: " + vehiculo.getTipo());
        }

        // Cálculo: horas exactas hacia arriba, mínimo 1 fracción
        double horas = minutosEstacionado / 60.0;
        double costo = Math.ceil(horas) * tarifa.getPrecioPorHora();

        return Math.max(costo, tarifa.getPrecioMinimo());
    }
}
