package parqueadero.estrategia;

import parqueadero.modelo.Vehiculo;

/**
 * EstrategiaTarifa — abstracción de la estrategia de cálculo de tarifas.
 * SOLID: DIP — CalculadorTarifa y servicios de alto nivel dependen de esta abstracción.
 *        OCP — nuevas estrategias de tarifa se agregan sin modificar el calculador.
 */
public interface EstrategiaTarifa {
    /**
     * Calcula el costo para un vehículo dado el tiempo en minutos.
     */
    double calcular(Vehiculo vehiculo, long minutosEstacionado);
}
